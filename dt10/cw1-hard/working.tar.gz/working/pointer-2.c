
int main()
{

  int x=0;

  int *y=&x;

  x=y[0];

}
