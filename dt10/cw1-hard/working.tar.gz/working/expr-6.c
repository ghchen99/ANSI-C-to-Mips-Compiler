
int main()
{

  int x=5 << 6;
  x = 7

  >> x;

                                                                       x <<= 5;
  x >>= 6;

}
