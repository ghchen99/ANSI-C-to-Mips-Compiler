
int f()
{
int x=0+0;
int u=x-x;
int z= u  * u; 
int y= z / x;
 return y;
}
