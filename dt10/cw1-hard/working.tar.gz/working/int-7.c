int x= - 056;
