long int y;
float z;
