int
 x=
   '0'
      ;
