int   x=   '\012'
;
