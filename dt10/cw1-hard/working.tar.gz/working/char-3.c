   int    x   = '_'     ;
