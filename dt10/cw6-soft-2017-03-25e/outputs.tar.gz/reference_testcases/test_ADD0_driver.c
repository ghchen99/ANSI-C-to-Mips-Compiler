
int f(int x, int y);

int main()
{
    return !( 40 == f(30,10) );
}
