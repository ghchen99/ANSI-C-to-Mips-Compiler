
int f();

int main()
{
    return !( 10==f() );
}
